﻿//Console.WriteLine("Hello, World!");
//Console.WriteLine("\t\ncmd");
//  Console - ввод вывод в консоли ;
//  WriteLine - ввод ;
// \t - табуляция ; \n - новая строка ; \a - сигнал ;
//Console.Write("как дела ?"); // Write - пишет все в одну строку;
//Console.Write(" нормально \a\n");
//Console.WriteLine(15 + 4);
//Console.WriteLine(56 - 4);
//Console.WriteLine(12 * 9);
//Console.WriteLine((15 + 12) * 6); // так же WriteLine работает с выражениями 

//int Kampf = 1488;
//Console.WriteLine(Kampf);

//Kampf += 1312; //  если хотим  + или - ставим действие перед =;

//Console.WriteLine(Kampf);
//Console.WriteLine($"Число равно {Kampf}"); // $ - подставляет значение с переменной ;


// Readline - дает возможность вводить данные в консоль самому ;
//Console.WriteLine("Введите строку: ");
//int s = Convert.ToInt32(Console.ReadLine());//Convert - конвертация любых топов данных ;
//string? s = Console.ReadLine(); //ReadLine - всегда строка; 
// int   - Int32 
// long  - Int64
// short - Int16
// byte  - Int8
//Console.WriteLine($"Результат {s + s}");

Console.WriteLine("введите первое число: ");
int num1 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введите второе число: ");
int num2 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine($"Результат: {num1 + num2}");
Console.WriteLine($"Результат: {num1 - num2}");
Console.WriteLine($"Результат: {num1 * num2}");
Console.WriteLine($"Результат: {num1 / num2}");
Console.WriteLine($"Результат: {Math.Pow(num1,num2)}");



