﻿// Цикл тема - #1
using System.Xml.Linq;

namespace ConsoleApp46
{
    internal class Program
    {

        //Функция тема - #2
        public static void Summa(int a, int b)
        {
            Console.WriteLine($"{a} + {b} = {a + b}");
        
        }

        public static void introduce(string name, int age,string job)
        {
            Console.WriteLine("Хай ");
            Console.WriteLine($"Меня зовут {name}");
            Console.WriteLine($"Мой возраст {age}");
            Console.WriteLine($"Моя професиия {job}");




        }

        
        static void Main(string[] args)
        {
            
           Summa(67, 5);
            Summa(55,2);
            Summa(23,7);
            Summa(14,88);
            Summa(28,8);

            introduce("Тагир",18,"Хацкер");



            Console.WriteLine("Зейнудин");
            Console.WriteLine("Джамал");
            Console.WriteLine("Малик");
            
            
            //for (int i = 1; i <= 10; i++)
            //{
            //    // Второй цикл, первый ждет пока выполнится второй.
            //    for (int j = 1; j <= 10; j++)

            //    {
            //        Console.WriteLine($"{j} * {j} = {i * j}");
            //    }

            //}
            //Console.WriteLine(" -Цикл закончен!");

            //int iter = 0;
            //while(iter <= 20)
            //{
            //    Console.WriteLine(" 14/88 | 282 - УК РФ ");
            //    iter++;
            //}

            //do
            //{
            //    Console.WriteLine("выполняю do while..");
            //    iter++;
            //} while (iter < 1);
        
        
        }
    }
}
